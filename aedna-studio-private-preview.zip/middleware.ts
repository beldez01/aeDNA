import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(req: NextRequest) {
  const url = new URL(req.url);
  const cookieOK = req.cookies.get("auth_ok")?.value === "1";

  if (cookieOK || url.pathname.startsWith("/api/") || url.pathname.startsWith("/_next") || url.pathname === "/favicon.ico") {
    return NextResponse.next();
  }

  const pass = url.searchParams.get("pass");
  if (pass && pass === process.env.APP_PASSWORD) {
    const res = NextResponse.redirect(new URL(url.pathname || "/", req.url));
    res.cookies.set("auth_ok", "1", { httpOnly: true, sameSite: "lax", secure: true, path: "/" });
    return res;
  }

  return new NextResponse(
    `<html><body style="font-family:ui-sans-serif;padding:2rem;background:#0a0a0a;color:#e5e5e5">
      <h3 style="margin:0 0 1rem 0">Private Preview</h3>
      <form>
        <input name="pass" type="password" placeholder="Password"
          style="padding:.5rem;border:1px solid #404040;background:#111;color:#e5e5e5;border-radius:.5rem" />
        <button type="submit" style="margin-left:.5rem;padding:.5rem .75rem;border:1px solid #404040;background:#181818;color:#e5e5e5;border-radius:.5rem">
          Enter
        </button>
      </form>
    </body></html>`,
    { status: 401, headers: { "Content-Type": "text/html" } }
  );
}

export const config = { matcher: ["/((?!_next|favicon.ico).*)"] };
