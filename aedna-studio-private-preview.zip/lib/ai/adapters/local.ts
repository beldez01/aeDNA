import type { AIAdapter, AIJob, AIResult } from "../adapter";

export const LocalAdapter: AIAdapter = {
  name: "local",
  supported: (_job: AIJob) => true,
  run: async (job: AIJob): Promise<AIResult> => {
    if (job.kind === "upscale") {
      return { ok: true, image: job.image, meta: { note: "stub upscale" } };
    }
    if (job.kind === "inpaint") {
      return { ok: true, image: job.image, meta: { note: "stub inpaint" } };
    }
    return { ok: false, error: "Unsupported job" };
  }
};
