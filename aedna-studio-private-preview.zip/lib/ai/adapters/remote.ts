import type { AIAdapter, AIJob, AIResult } from "../adapter";

export const RemoteAdapter: AIAdapter = {
  name: "remote",
  supported: (_job: AIJob) => true,
  run: async (_job: AIJob): Promise<AIResult> => {
    return { ok: false, error: "Remote adapter not wired yet" };
  }
};
