import type { AIJob, AIResult } from "./adapter";
import { LocalAdapter } from "./adapters/local";
import { RemoteAdapter } from "./adapters/remote";

const adapters = [LocalAdapter, RemoteAdapter];

export async function runAI(job: AIJob): Promise<AIResult> {
  for (const a of adapters) if (a.supported(job)) return a.run(job);
  return { ok: false, error: "No adapter could handle this job." };
}
