export type AIJob =
  | { kind: "inpaint"; image: ImageData; mask: ImageData; seed?: number; model?: string }
  | { kind: "upscale"; image: ImageData; factor: number; model?: string };

export type AIResult =
  | { ok: true; image: ImageData; meta?: Record<string, unknown> }
  | { ok: false; error: string };

export interface AIAdapter {
  name: string;
  supported(job: AIJob): boolean;
  run(job: AIJob): Promise<AIResult>;
}
