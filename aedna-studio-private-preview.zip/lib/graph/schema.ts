import { z } from "zod";

export const nodeType = z.enum([
  "load-image",
  "crop",
  "mask",
  "ai-inpaint",
  "vectorize",
  "layout",
  "export"
]);

export const node = z.object({
  id: z.string(),
  type: nodeType,
  params: z.record(z.any()).default({}),
  next: z.string().optional()
});

export const graphSchema = z.object({
  id: z.string(),
  nodes: z.array(node).min(1)
});

export type Graph = z.infer<typeof graphSchema>;
