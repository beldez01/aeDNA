# aeDNA Studio (Private Preview)

## Quick start
1) `npm i`
2) `cp .env.example .env.local` and set `APP_PASSWORD`.
3) `npm run dev` → open `http://localhost:3000?pass=YOUR_PASSWORD`.

## Deploy (Vercel)
- Push to a **private** GitHub repo.
- Import in Vercel → Project Settings → Environment Variables:
  - `APP_PASSWORD` = your password
- Deploy → visit the URL and append `?pass=YOUR_PASSWORD` on first load.

## Architecture highlights
- **Password gate**: `middleware.ts` sets a cookie after `?pass=...`.
- **AI adapter**: `lib/ai` allows swapping local (WebGPU/WASM) or remote (GPU API).
- **Node graph**: `lib/graph/schema.ts` + `components/NodeGraphStub.tsx`.
- **COOP/COEP headers**: ready for SharedArrayBuffer + WASM threads.

## Next steps
- Add Modular Crop UI and wire as a `crop` node.
- Implement `runAI()` against your preferred model(s).
- Add an `export` server route that embeds C2PA Content Credentials.
