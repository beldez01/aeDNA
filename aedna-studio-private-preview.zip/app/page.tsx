import ProtectedNote from "@/components/ProtectedNote";
import NodeGraphStub from "@/components/NodeGraphStub";

export default function Page() {
  return (
    <main className="space-y-8">
      <section className="space-y-2">
        <h1 className="text-2xl font-bold">aeDNA Studio — Private Preview</h1>
        <p className="text-neutral-300 max-w-2xl">
          Web-first design suite scaffold with password gate, AI adapter layer (local/remote),
          node-graph schema, and C2PA-ready export placeholder.
        </p>
        <ProtectedNote />
      </section>

      <section className="space-y-2">
        <h2 className="text-xl font-semibold">Pipelines (Graph)</h2>
        <NodeGraphStub />
      </section>

      <section className="space-y-2">
        <h2 className="text-xl font-semibold">Next steps</h2>
        <ol className="list-decimal ml-6 text-neutral-300">
          <li>Add your Modular Crop component (square/circle/polygon) as a <code>crop</code> node UI.</li>
          <li>Wire <code>runAI()</code> to your GPU API or WebGPU kernels.</li>
          <li>Add <code>export</code> node that embeds C2PA (server route).</li>
        </ol>
      </section>
    </main>
  );
}
