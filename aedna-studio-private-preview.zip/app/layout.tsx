export const metadata = { title: "aeDNA Studio (Private)", description: "Private preview" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen antialiased">
        <div className="mx-auto max-w-5xl p-6">
          <header className="sticky top-0 z-10 mb-8 bg-neutral-950/80 backdrop-blur border-b border-neutral-800">
            <div className="flex items-center justify-between py-4">
              <div className="font-semibold tracking-wide">aeDNA</div>
              <nav className="text-sm text-neutral-400">Private Preview</nav>
            </div>
          </header>
          {children}
        </div>
      </body>
    </html>
  );
}
