"use client";
import { useState } from "react";
import { graphSchema, type Graph } from "@/lib/graph/schema";

export default function NodeGraphStub() {
  const [json, setJson] = useState<Graph>({
    id: "demo-graph",
    nodes: [
      { id: "load1", type: "load-image", params: { src: "demo.jpg" }, next: "crop1" },
      { id: "crop1", type: "crop", params: { mode: "square", x: 10, y: 10, w: 512, h: 512 }, next: "export1" },
      { id: "export1", type: "export", params: { format: "png", c2pa: true } }
    ]
  });

  const validate = () => {
    const parsed = graphSchema.safeParse(json);
    alert(parsed.success ? "Graph is valid ✅" : JSON.stringify(parsed.error.issues, null, 2));
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Node Graph (stub)</h3>
        <button onClick={validate} className="rounded-lg border border-neutral-700 px-3 py-1 text-sm hover:bg-neutral-800">
          Validate
        </button>
      </div>
      <pre className="bg-neutral-900 border border-neutral-800 rounded-xl p-4 overflow-x-auto text-xs">
        {JSON.stringify(json, null, 2)}
      </pre>
    </div>
  );
}
