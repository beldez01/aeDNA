export default function ProtectedNote() {
  return (
    <p className="text-xs text-neutral-400">
      This preview is password-gated via <code>middleware.ts</code>. To unlock a new browser,
      append <code>?pass=YOUR_PASSWORD</code> to the URL once.
    </p>
  );
}
